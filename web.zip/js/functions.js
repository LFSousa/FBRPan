function load(page){
	$("#container").html("<div id='loading'>Carregando...</div>");
	$("#container").load("templates/"+page+".tpl");
}
$("li.item").on("click", function(){
	if(this.id == "sair"){
		sessionStorage.clear();
		window.location = "entrar.html";
	}
	$(".active").addClass("item").removeClass("active");
	$(this).removeClass("item").addClass("active");
	load(this.id);
	window.location = "#"+this.id;
});
if(window.location.hash) {
      var hash = window.location.hash.substring(1);
      $("#"+hash).removeClass("item").addClass("active");
		load(hash);
  } else {
      $("#status").removeClass("item").addClass("active");
		load("status");
		window.location = "#status";
  }

  if(sessionStorage.getItem("user") == null){
	  window.location = "entrar.html";
  }