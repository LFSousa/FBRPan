<?php
$con = new PDO('mysql:host=127.0.0.1;dbname=dbname', 'dbuser', 'dbpass');

$rs = $con->prepare("SELECT * FROM users WHERE user = ? AND pass = ?");
$pass = $_GET["pass"];
$rs->bindParam(1, $_GET["user"]);
$rs->bindParam(2, $pass);
if($rs->execute()){
if($rs->rowCount() > 0){
$row = $rs->fetch(PDO::FETCH_OBJ);
	if(!isset($_GET["act"])){
	echo $row->emu_name;
	}
	else if($_GET["act"] == "tcp"){
		echo $row->tcp;
	}
	else if($_GET["act"] == "mus"){
		echo $row->mus;
	}
}
else{
	echo "0";
}
}